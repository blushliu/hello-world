package com.sdcet.javaweb.domain;

public class NewClass {
	private String leibie;
	private String jianjie;
	public NewClass() {
	}
	public String getLeibie() {
		return leibie;
	}
	public void setLeibie(String leibie) {
		this.leibie = leibie;
	}
	public String getJianjie() {
		return jianjie;
	}
	public void setJianjie(String jianjie) {
		this.jianjie = jianjie;
	}
	
}
