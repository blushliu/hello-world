package com.sdcet.javawebproject;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sdcet.dao.jdbc.JdbcImpl;
import com.sdcet.dao.jdbc.UserDao;
import com.sdcet.javaweb.domain.User;

public class loginservlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("user");
		String password = request.getParameter("password");
		
		UserDao dao = new JdbcImpl();
		
		List<User> users = dao.userEq(username);
		if(users!=null){
			for(User uu:users){
				String nam = uu.getName();
				String pas = uu.getPassword();
				String pow = uu.getPower();
				if(username.equals(nam)&&password.equals(pas)){
					System.out.println("ƥ��ɹ�");
					
					HttpSession hs = request.getSession();
					hs.setAttribute("users", username);
					hs.setAttribute("power", pow);
					response.sendRedirect("houtai1.jsp");//���Ե�ʱ������  ��Ϊ����
					
				}
				else{
					System.out.println("������û�������ȷ");
					
					request.setAttribute("sss","�û������������");
					RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
					rd.forward(request,response);
					
				}
			}
			
		}
		if(users.isEmpty()){
			System.out.println("û�鵽");
			request.setAttribute("namess", username);
			request.setAttribute("sss","�û������������");
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request,response);
			
		}
			
			
		
		
		
		
	}


}
