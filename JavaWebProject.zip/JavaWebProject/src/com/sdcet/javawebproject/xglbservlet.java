package com.sdcet.javawebproject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdcet.dao.newclass.JdbcImplNewClass;
import com.sdcet.dao.newclass.NewClassDao;

public class xglbservlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String lei = request.getParameter("leidemingzi");
		String leibie = request.getParameter("leibie");
		String leibiejianjie = request.getParameter("leibiejianjie");
		System.out.println(leibie+" "+leibiejianjie);
		
		NewClassDao dao = new JdbcImplNewClass();
		dao.updatenewclass(lei, leibie, leibiejianjie);
		
		
		RequestDispatcher rd = request.getRequestDispatcher("leibie.jsp");
		rd.forward(request, response);
		
	}

}
