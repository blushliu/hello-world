package com.sdcet.javawebproject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdcet.dao.pinglunjdbc.JdbcImplPingLun;
import com.sdcet.dao.pinglunjdbc.PingLunDao;

public class fabiaopinglun extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		Date nowTime = new Date();
		SimpleDateFormat matter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String shijian = matter.format(nowTime);
		
		String biaoti = request.getParameter("biaotis");
		String pinglun = request.getParameter("textarea");
	
		String nicheng = request.getParameter("username");
		PingLunDao pld = new JdbcImplPingLun();
		System.out.println(biaoti);
		if(nicheng.isEmpty()){
			nicheng="����";
		}
		pld.setPinglun(biaoti,pinglun,shijian,nicheng);
		RequestDispatcher rd = request.getRequestDispatcher("xiangxineirong.jsp?title="+biaoti);
		rd.forward(request, response);
		
	}

}
