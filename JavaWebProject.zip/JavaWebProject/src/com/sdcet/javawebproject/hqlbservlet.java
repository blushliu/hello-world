package com.sdcet.javawebproject;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdcet.dao.jdbc.JdbcImpl;
import com.sdcet.dao.jdbc.NewsDao;

public class hqlbservlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("utf-8");
		
		NewsDao dao = new JdbcImpl();
		List<String> leibie = dao.getLeiBie();
		for(String lb :leibie){
			System.out.println(lb);
		}
		
	}

}
