package com.sdcet.javawebproject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdcet.dao.jdbc.JdbcImpl;
import com.sdcet.dao.jdbc.NewsDao;

public class tjxwservlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		
		String leibie = request.getParameter("leibie");
		String title = request.getParameter("title");
		String zuozhe = request.getParameter("zuozhe");
		String laiyuan = request.getParameter("laiyuan");
		System.out.println(laiyuan);
		String neirong = request.getParameter("content");
		System.out.println(neirong);
	
		Date nowTime = new Date();
		SimpleDateFormat matter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = matter.format(nowTime);
		
		NewsDao nd = new JdbcImpl();
		nd.addNews(leibie,title,zuozhe,laiyuan,neirong,time);
		
		RequestDispatcher rd = request.getRequestDispatcher("xinwen0.jsp");
		rd.forward(request, response);
		
	}

}
