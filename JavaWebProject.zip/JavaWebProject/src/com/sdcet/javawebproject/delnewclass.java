package com.sdcet.javawebproject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sdcet.dao.newclass.JdbcImplNewClass;
import com.sdcet.dao.newclass.NewClassDao;

public class delnewclass extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		String s = request.getParameter("leibie");
		
		System.out.println(s);
		NewClassDao newclass = new JdbcImplNewClass();
		newclass.delnewclass(s);
		
		RequestDispatcher rd = request.getRequestDispatcher("leibie.jsp");
		rd.forward(request,response);
		
		
	}

}
