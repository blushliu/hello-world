package com.sdcet.dao.pinglunjdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.sdcet.javaweb.domain.News;
import com.sdcet.javaweb.domain.PingLun;

public class JdbcImplPingLun implements PingLunDao {
private DataSource dataSource;
	
	public JdbcImplPingLun() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/news");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new RuntimeException("��������Դʧ�ܣ�" + e.getMessage());
		}
	}

	@Override
	public List<PingLun> getPinglun(String biaoti) {
		List<PingLun> pl = new ArrayList<PingLun>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select * from pinglun where biaoti=? order by shijian asc");
			ps.setString(1,biaoti);
			rs = ps.executeQuery();
			while(rs.next()) {
				PingLun ping = new PingLun(); 
				ping.setBiaoti(rs.getString(1));
				ping.setPinglun(rs.getString(2));
				ping.setShijian(rs.getString(3));
				ping.setNicheng(rs.getString(4));
			
				pl.add(ping);
				
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ��������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return pl;
	}

	@Override
	public void setPinglun(String biaoti,String pinglun,String shijian,String nicheng) {
	
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("insert into pinglun values(?,?,?,?)");
			ps.setString(1,biaoti);
			ps.setString(2,pinglun);
			ps.setString(3,shijian);
			ps.setString(4,nicheng);
			ps.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��������ʧ��");
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		}
	}

}
