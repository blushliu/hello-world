package com.sdcet.dao.pinglunjdbc;

import java.util.List;

import com.sdcet.javaweb.domain.PingLun;

public interface PingLunDao {
	public List<PingLun> getPinglun(String biaoti);
	public void setPinglun(String biaoti,String pinglun,String shijian,String nicheng);
	
}
