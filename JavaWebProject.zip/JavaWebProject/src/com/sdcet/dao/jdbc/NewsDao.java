package com.sdcet.dao.jdbc;

import java.util.List;

import com.sdcet.javaweb.domain.News;

/**
 * ��ȡ�����������
 * @author 79433
 *
 */

public interface NewsDao {
	public void addLeiBie(String name,String jianjie);
	public List<News> getAllNews();
	public List<String> getLeiBie();
	public void addNews(String leibie,String biaoti,String zuozhe,String laiyuan,String neirong,String shijian);
	public void delnews(String title);
	public News getNews(String biaot);
	public void updateNews(String leibie,String biaoti,String zuozhe,String laiyuan,String neirong,String shijian,String jiubiaoti);
	public List<News> getNewinLeibie();
	public String getinLeibie();
	
	
	public List<News> getNewinLeibie2();
	public String getinLeibie2();
	
	public List<News> getNewss(String leibie);
	
	public List<News> mohuchaxun(String key,String fangshi);
	

}
