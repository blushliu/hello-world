package com.sdcet.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.sdcet.javaweb.domain.News;
import com.sdcet.javaweb.domain.User;

public class JdbcImpl implements UserDao,NewsDao{
	
private DataSource dataSource;
	
	public JdbcImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/news");
		} catch (NamingException e) {
			e.printStackTrace();
			throw new RuntimeException("��������Դʧ�ܣ�" + e.getMessage());
		}
	}
	public List<User> userEq(String user) {
		List<User> users = new ArrayList<User>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select * from users where name=?");
			ps.setString(1, user);
			
			rs = ps.executeQuery();
		
			
			while(rs.next()) {
				User u = new User();
				u.setName(rs.getString(1));
				u.setPassword(rs.getString(2));
				u.setPower(rs.getString(3));
				users.add(u);
			}
		
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return users;
	}
	
	public List<String> getLeiBie() {
		List<String> allleibie = new ArrayList<String>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select distinct leibie from newclass");
			rs = ps.executeQuery();
			while(rs.next()) {
				allleibie.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ȡ��������б�ʧ�ܣ�" + e.getMessage());
		} finally {
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		}
		
		return allleibie;
	}


	@Override
	public List<News> getAllNews() {
		List<News> listnews = new ArrayList<News>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select* from news");
			rs = ps.executeQuery();
			while(rs.next()) {
				News xws = new News(); 
				xws.setBiaoti(rs.getString(2));
				xws.setShijian(rs.getString(6));
				listnews.add(xws);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ��������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return listnews;
	}


	@Override
	public void addLeiBie(String name,String jianjie) {
		
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("insert into newclass values(?,?)");
			ps.setString(1,name);
			ps.setString(2,jianjie);
			ps.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("�����������ʧ��");
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		}
		

	}
	public void addNews(String leibie,String biaoti,String zuozhe,String laiyuan,String neirong,String shijian) {
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("insert into news values(?,?,?,?,?,?)");
			ps.setString(1,leibie);
			ps.setString(2,biaoti);
			ps.setString(3,zuozhe);
			ps.setString(4,laiyuan);
			ps.setString(5,neirong);
			ps.setString(6,shijian);
			ps.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
	}
	@Override
	public void delnews(String title) {
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("delete news where biaoti=?");
			ps.setString(1,title);
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
	}
	@Override
	public News getNews(String biaot) {
		List<News> listnews = new ArrayList<News>();
		News xws = new News(); 
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select* from news where biaoti=?");
			ps.setString(1,biaot);
			rs = ps.executeQuery();
			while(rs.next()) {
				
				xws.setLeibie(rs.getString(1));
				xws.setBiaoti(rs.getString(2));
				xws.setZuozhe(rs.getString(3));
				xws.setLaiyuan(rs.getString(4));
				xws.setNeirong(rs.getString(5));
				xws.setShijian(rs.getString(6));
				
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ��������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return xws;
	}
	@Override
	public void updateNews(String leibie,String biaoti,String zuozhe,String laiyuan,String neirong,String shijian,String jiubiaoti) {
			Connection connection = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			try {
				connection = dataSource.getConnection();
				ps = connection.prepareStatement("update news set leibie=?,biaoti=?,zuozhe=?,laiyuan=?,neirong=?,shijian=? where biaoti=?");
				ps.setString(1,leibie);
				ps.setString(2,biaoti);
				ps.setString(3,zuozhe);
				ps.setString(4,laiyuan);
				ps.setString(5,neirong);
				ps.setString(6,shijian);
				ps.setString(7,jiubiaoti);
				ps.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("��������ʧ��:"+e.getMessage());
			}finally{
				try {
					if(rs != null) {
						rs.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(ps != null) {
							ps.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
					} finally {
						try {
							if(connection != null) {
								connection.close();
							}
						} catch (SQLException e) {
							e.printStackTrace();
							throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
						}
					}
				}
			}
		
		
		
	}
	@Override
	public List<News> getNewinLeibie() {
		List<News> listnews = new ArrayList<News>();
		
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select top 5* from news where leibie in(select top 1 leibie from newclass order by leibie desc)");
			rs = ps.executeQuery();
			while(rs.next()) {
				News xws = new News(); 
				xws.setLeibie(rs.getString(1));
				xws.setBiaoti(rs.getString(2));
				xws.setZuozhe(rs.getString(3));
				xws.setLaiyuan(rs.getString(4));
				xws.setNeirong(rs.getString(5));
				xws.setShijian(rs.getString(6));
				listnews.add(xws);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ���������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return listnews;
	}
	@Override
	public String getinLeibie() {
		String lei="";
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select top 1 leibie from newclass order by leibie desc");
			rs = ps.executeQuery();
			while(rs.next()) {
				lei=rs.getString(1);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ���������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return lei;
	}
	@Override
	public List<News> getNewinLeibie2() {
			List<News> listnews = new ArrayList<News>();
			
			Connection connection = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			try {
				connection = dataSource.getConnection();
				ps = connection.prepareStatement("select top 5* from news where leibie in(select leibie from newclass  where id=2)");
				rs = ps.executeQuery();
				while(rs.next()) {
					News xws = new News(); 
					xws.setLeibie(rs.getString(1));
					xws.setBiaoti(rs.getString(2));
					xws.setZuozhe(rs.getString(3));
					xws.setLaiyuan(rs.getString(4));
					xws.setNeirong(rs.getString(5));
					xws.setShijian(rs.getString(6));
					listnews.add(xws);
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("��ʾ���������ʧ��"+e.getMessage());
			}finally{
				try {
					if(rs != null) {
						rs.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(ps != null) {
							ps.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
					} finally {
						try {
							if(connection != null) {
								connection.close();
							}
						} catch (SQLException e) {
							e.printStackTrace();
							throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
						}
					}
				}
			
			}
			return listnews;
	}
	@Override
	public String getinLeibie2() {
		String lei="";
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement("select leibie from newclass  where id=2");
			rs = ps.executeQuery();
			while(rs.next()) {
				lei=rs.getString(1);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ���������ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return lei;
	}
	@Override
	public List<News> getNewss(String leibie) {
			List<News> listnews = new ArrayList<News>();
			Connection connection = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			
			try {
				connection = dataSource.getConnection();
				ps = connection.prepareStatement("select * from news where leibie=?");
				ps.setString(1,leibie);
				rs = ps.executeQuery();
				while(rs.next()) {
					News xws = new News(); 
					xws.setLeibie(rs.getString(1));
					xws.setBiaoti(rs.getString(2));
					xws.setZuozhe(rs.getString(3));
					xws.setLaiyuan(rs.getString(4));
					xws.setNeirong(rs.getString(5));
					xws.setShijian(rs.getString(6));
					listnews.add(xws);
				}
			
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("��ʾ���������ʧ��"+e.getMessage());
			}finally{
				try {
					if(rs != null) {
						rs.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(ps != null) {
							ps.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
					} finally {
						try {
							if(connection != null) {
								connection.close();
							}
						} catch (SQLException e) {
							e.printStackTrace();
							throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
						}
					}
				}
			
			}
			return listnews;
	}
	@Override
	public List<News> mohuchaxun(String guanjianzi,String fangshi) {
		List<News> listnews = new ArrayList<News>();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			System.out.println("�ؼ��֣�"+guanjianzi);
			System.out.println("��ʽ��"+fangshi);
			ps = connection.prepareStatement("select * from news where "+fangshi+" like ?");
			ps.setString(1,"%"+guanjianzi+"%");
			
			
			rs = ps.executeQuery();
		
			while(rs.next()) {
				News xws = new News(); 
				xws.setLeibie(rs.getString(1));
				xws.setBiaoti(rs.getString(2));
				xws.setZuozhe(rs.getString(3));
				xws.setLaiyuan(rs.getString(4));
				xws.setNeirong(rs.getString(5));
				xws.setShijian(rs.getString(6));
				listnews.add(xws);
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("��ʾ����ʧ��"+e.getMessage());
		}finally{
			try {
				if(rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("�رս����ʧ�ܣ�" + e.getMessage());
			} finally {
				try {
					if(ps != null) {
						ps.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException("�ر�PreparedStatementʧ�ܣ�" + e.getMessage());
				} finally {
					try {
						if(connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						throw new RuntimeException("�ر�Connectionʧ�ܣ�" + e.getMessage());
					}
				}
			}
		
		}
		return listnews;
	}
}
