package com.sdcet.dao.hibernate;

import java.util.List;

import com.sdcet.dao.jdbc.UserDao;
import com.sdcet.javaweb.domain.User;

public class UserDaoHibernateImpl implements UserDao {

	public List<User> userEq(String user) {
		// TODO Auto-generated method stub
		return null;
	}
}
