package com.sdcet.dao.newclass;

public interface NewClassDao {
	
	public void delnewclass(String name);
	public void updatenewclass(String leibie,String xinleibie,String xinjianjie);

}
